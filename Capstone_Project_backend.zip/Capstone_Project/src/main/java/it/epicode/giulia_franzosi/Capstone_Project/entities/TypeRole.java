package it.epicode.giulia_franzosi.Capstone_Project.entities;

public enum TypeRole {
	ROLE_USER,
	ROLE_ADMIN
}
