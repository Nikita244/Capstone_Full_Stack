package it.epicode.giulia_franzosi.Capstone_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
